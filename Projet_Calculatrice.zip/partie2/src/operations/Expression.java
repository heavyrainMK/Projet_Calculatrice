package operations;

// Classe abstraite Expression
public abstract class Expression {
    public abstract int valeur();
}