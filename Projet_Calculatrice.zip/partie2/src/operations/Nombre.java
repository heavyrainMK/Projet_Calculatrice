package operations;

// Classe Nombre modifiée pour hériter d'Expression
public class Nombre extends Expression {
    private int valeurNombre;
    
    public Nombre(int valeur) {
        this.valeurNombre = valeur;
    }
    
    @Override
    public int valeur() {
        return valeurNombre;
    }
    
    @Override
    public String toString() {
        return String.valueOf(valeurNombre);
    }
}