package test;

import operations.*;

// Classe de test pour la partie 2
public class TestPartie2 {
    public static void main(String[] args) {
        // Test de l'exemple donné : (17-2)/(2+3)
        Expression deux = new Nombre(2);
        Expression trois = new Nombre(3);
        Expression dixSept = new Nombre(17);
        Expression s = new Soustraction(dixSept, deux);
        Expression a = new Addition(deux, trois);
        Expression d = new Division(s, a);
        System.out.println(d + " = " + d.valeur()); // affiche ((17 - 2) / (2 + 3)) = 3
        
        // Test supplémentaire avec une expression plus complexe
        // ((4 * 2) + (10 - 3)) * 2
        Expression quatre = new Nombre(4);
        Expression dix = new Nombre(10);
        Expression mult = new Multiplication(quatre, deux);
        Expression sous = new Soustraction(dix, trois);
        Expression add = new Addition(mult, sous);
        Expression resultat = new Multiplication(add, deux);
        System.out.println(resultat + " = " + resultat.valeur());
        
        // Test 3: Expression avec plusieurs opérations différentes
        // ((5 + 7) * (20 / 4)) - 6
        Expression cinq = new Nombre(5);
        Expression sept = new Nombre(7);
        Expression vingt = new Nombre(20);
        Expression six = new Nombre(6);
        
        Expression add1 = new Addition(cinq, sept);
        Expression div1 = new Division(vingt, quatre);
        Expression mult1 = new Multiplication(add1, div1);
        Expression resultat3 = new Soustraction(mult1, six);
        System.out.println(resultat3 + " = " + resultat3.valeur()); // ((5 + 7) * (20 / 4)) - 6 = 24
        
        // Test 4: Expression avec opérations imbriquées profondes
        // (3 + ((8 - 2) * (12 / (3 + 1))))
        Expression huit = new Nombre(8);
        Expression douze = new Nombre(12);
        Expression un = new Nombre(1);
        
        Expression add2 = new Addition(trois, un);
        Expression div2 = new Division(douze, add2);
        Expression sous2 = new Soustraction(huit, deux);
        Expression mult2 = new Multiplication(sous2, div2);
        Expression resultat4 = new Addition(trois, mult2);
        System.out.println(resultat4 + " = " + resultat4.valeur()); // (3 + ((8 - 2) * (12 / (3 + 1)))) = 21
        
        // Test 5: Expression avec division qui donne un résultat à virgule (tronquée en entier)
        // (100 / 30) + 2
        Expression cent = new Nombre(100);
        Expression trente = new Nombre(30);
        Expression div3 = new Division(cent, trente);
        Expression resultat5 = new Addition(div3, deux);
        System.out.println(resultat5 + " = " + resultat5.valeur()); // (3 + 2) = 5
        
        // Test 6: Test avec valeurs négatives
        // (-5 * 4) + (10 / 2)
        Expression negCinq = new Nombre(-5);
        Expression mult3 = new Multiplication(negCinq, quatre);
        Expression div4 = new Division(dix, deux);
        Expression resultat6 = new Addition(mult3, div4);
        System.out.println(resultat6 + " = " + resultat6.valeur()); // ((-5 * 4) + (10 / 2)) = -15
    }
}