package operations;

// Classe Nombre
public class Nombre {
    private int valeurNombre;
    
    public Nombre(int valeur) {
        this.valeurNombre = valeur;
    }
    
    public int valeur() {
        return valeurNombre;
    }
    
    @Override
    public String toString() {
        return String.valueOf(valeurNombre);
    }
}