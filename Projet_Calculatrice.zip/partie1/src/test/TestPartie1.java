package test;

import operations.*;

// Classe de test pour la partie 1
public class TestPartie1 {
    public static void main(String[] args) {
        // Test des opérations simples
        Nombre six = new Nombre(6);
        Nombre dix = new Nombre(10);
        
        Operation s = new Soustraction(dix, six);
        System.out.println(s + " = " + s.valeur()); // doit afficher : (10 - 6) = 4
        
        Operation a = new Addition(dix, six);
        System.out.println(a + " = " + a.valeur());
        
        Operation m = new Multiplication(dix, six);
        System.out.println(m + " = " + m.valeur());
        
        Operation d = new Division(dix, six);
        System.out.println(d + " = " + d.valeur());
    }
}